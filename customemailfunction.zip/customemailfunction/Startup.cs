﻿
using System;
using System.IO;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using Solar.AD.Custom.Apis;
using Solar.AD.Custom.Apis.Services;
using System;

[assembly: FunctionsStartup(typeof(Startup))]
namespace Solar.AD.Custom.Apis
{

    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            if(builder ==null) throw new ArgumentNullException(nameof(builder));

            var localRoot = Environment.GetEnvironmentVariable("AzureWebJobsScriptRoot");
            var azureRoot = $"{Environment.GetEnvironmentVariable("Home")}/site/wwwroot";
            var actualroot = localRoot ?? azureRoot;

            var config = new ConfigurationBuilder()
             .SetBasePath(actualroot)

#if DEBUG
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
#endif

             .AddEnvironmentVariables()
            .Build();
       
            builder.Services.AddHttpClient();
            builder.Services.AddRefitClient<IDrupalServices>() // Now passing refitSettings to Refit
              .ConfigureHttpClient(httpClient =>
              {
                  httpClient.BaseAddress = new Uri("https://prod.scc.my-sandoz.com");
              });

        }
    }
}
