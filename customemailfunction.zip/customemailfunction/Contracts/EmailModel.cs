﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Solar.AD.Custom.Apis.Contracts
{
    public class EmailModel
    {
        public List<Personalization> personalizations { get; set;}

        [JsonProperty("from")]
        public EmailAddress From { get; set; }
    }

}
