﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Solar.AD.Custom.Apis.Contracts
{
    public sealed class Personalization
    {
        [JsonProperty("to")]
        public IList<EmailAddress> To { get; set; }

        [JsonProperty("dynamic_template_data")]
        public DynamicTemplateData dynamicTemplateData { get; set; }
    }

}
