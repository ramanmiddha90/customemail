﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Solar.AD.Custom.Apis.Contracts.Drupal
{
    public class OAuthRequest
    {
        public string grant_type = "client_credentials";

        [JsonProperty("client_id")]
        public string client_id { get; set; }

        [JsonProperty("client_secret")]
        public string client_secret { get; set; }
    }
}
