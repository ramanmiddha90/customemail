﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Solar.AD.Custom.Apis.Contracts.Drupal
{
    public sealed class DrupalEmailRequest
    {
        [JsonProperty("webform_id")]
        public string webform_id { get; set; }

        [JsonProperty("to")]
        public string To { get; set; }

        [JsonProperty("from")]
        public string From { get; set; }

        [JsonProperty("subject")]
        public string Subject { get; set; }

        [JsonProperty("body")]
        public string Body { get; set; }
    }
}
