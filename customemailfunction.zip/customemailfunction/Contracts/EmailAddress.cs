﻿namespace Solar.AD.Custom.Apis.Contracts
{
    public class EmailAddress
    {
        public string email { get; set; }
    }
}
