﻿using Newtonsoft.Json;

namespace Solar.AD.Custom.Apis.Contracts
{
    public sealed class DynamicTemplateData
    {
        [JsonProperty("otp")]
        public string Otp { get; set; }

        [JsonProperty("subject")]
        public string Subject { get; set; }
    }
}
