using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Solar.AD.Custom.Apis.Contracts;
using Solar.AD.Custom.Apis.Extensions;
using Solar.AD.Custom.Apis.Services;
using System;
using System.IO;
using System.Threading.Tasks;

namespace Solar.AD.Custom.Apis
{
    public class SendEmailFunction
    {
        private IDrupalServices _drupalSerice;
        private TokenAccesser _tokenAccesser;
        public SendEmailFunction(IDrupalServices drupalService)
        {
            _drupalSerice = drupalService;
            _tokenAccesser = new TokenAccesser(drupalService);

        }
        [FunctionName("SendEmail")]
        public async Task<IActionResult> SendEmail(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "solar/webforms/email")] HttpRequest req,
            ILogger log)
        {
            try
            {
                var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                var emailRequest = JsonConvert.DeserializeObject<EmailModel>(requestBody);

                log.LogInformation($"Request : {requestBody}");

                var token = await _tokenAccesser.GetBearerTokenAsync();

                if (string.IsNullOrEmpty(token))
                    return new BadRequestObjectResult("yoke not found");

                var response = await _drupalSerice.SendEmail(emailRequest.ToDrupalEmailRequest(), $"Bearer {token}");

                return new OkResult();
            }
            catch (JsonSerializationException ex)
            {
                return new BadRequestObjectResult("Invalid Email Request");
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult($"{ex.Message}:{ex.StackTrace}");
            }

        }

    }
}
