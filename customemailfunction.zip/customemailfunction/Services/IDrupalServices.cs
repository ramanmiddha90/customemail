﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Refit;
using Solar.AD.Custom.Apis.Contracts.Drupal;

namespace Solar.AD.Custom.Apis.Services
{
    public interface IDrupalServices
    {
        private const string AuthorizationHeader= "Authorization";

        [Multipart]
        [Post("/oauth/token")]
        public Task<ApiResponse<string>> GetAccessToken(string grant_type,string client_id, string client_secret);

        [Post("/webform_rest/submit")]
      
        public Task<string> SendEmail(
            DrupalEmailRequest request,
            [Header(AuthorizationHeader)] string accessToken);
    }
}
