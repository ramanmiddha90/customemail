﻿using Solar.AD.Custom.Apis.Contracts;
using Solar.AD.Custom.Apis.Contracts.Drupal;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Solar.AD.Custom.Apis
{
    public static class EmailExtensions
    {
        private const string WebFormID = "mailer_service";
        public static DrupalEmailRequest ToDrupalEmailRequest(this EmailModel emailModel)
        {
            return new DrupalEmailRequest
            {
                Body = BuildTemplate(emailModel),
                From = "raman-1.kumar_ext@novartis.com",
                To = emailModel?.personalizations?[0].To.First().email,
                Subject = emailModel?.personalizations?[0].dynamicTemplateData?.Subject,
                webform_id = WebFormID
            };
        }

        private static string BuildTemplate(EmailModel model)
        {
            var assy = Assembly.GetAssembly(typeof(EmailExtensions));
            Stream fileStream = assy.GetManifestResourceStream(typeof(EmailExtensions), "Assets.EmailBodyTemplate.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(fileStream))
            {
                body = reader.ReadToEnd()
                           .Replace("{{otp}}", model.personalizations.First().dynamicTemplateData.Otp)
                           .Replace("{{email}}", model.personalizations.First().To.First().email.ToString());
            }
            return body;

        }
    }
}
