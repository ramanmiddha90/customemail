﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Refit;
using Solar.AD.Custom.Apis.Contracts.Drupal;
using Solar.AD.Custom.Apis.Services;
using System;
using System.Threading.Tasks;

namespace Solar.AD.Custom.Apis.Extensions
{
    public class TokenAccesser
    {
        private IDrupalServices _drupalService;
        public TokenAccesser(IDrupalServices drupalService)
        {
            _drupalService = drupalService;
        }

        public async Task<string> GetBearerTokenAsync()
        {
            // In reality we'd log this error, but for our demo we'll return a fake token, since
            // our OAuth endpoint is always going to 404.
            const string defaultToken = "";
            try
            {
                OAuthRequest request = new OAuthRequest() { client_id = "sandoz_consumer", client_secret = "rjc9HhTekq_MOaD_xrZ" };
                ApiResponse<string?> result = await _drupalService.GetAccessToken(request.grant_type,request.client_id,request.client_secret);

                if (result.IsSuccessStatusCode)
                    return JsonConvert.DeserializeObject<JObject>(result.Content?.ToString()).SelectToken("access_token").ToString();

                return result.Content ?? defaultToken;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
